$(function() {
	$("#mus_h3_btn1").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile5/mus_h3_btn1.jsp', dataType: 'html', success: function(data) {
					$("#btn_open1").html(data);
				}
		});
	})
})
$(function() {
	$("#mus_h3_btn2").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile5/mus_h3_btn2.jsp', dataType: 'html', success: function(data) {
					$("#btn_open2").html(data);
				}
		});
	})
})
$(function() {
	$("#mus_h3_btn3").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile5/mus_h3_btn3.jsp', dataType: 'html', success: function(data) {
					$("#btn_open3").html(data);
				}
		});
	})
})
$(function() {
	$("#mus_h3_btn4").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile5/mus_h3_btn4.jsp', dataType: 'html', success: function(data) {
					$("#btn_open4").html(data);
				}
		});
	})
})
$(function() {
	$("#mus_h3_btn5").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile5/mus_h3_btn5.jsp', dataType: 'html', success: function(data) {
					$("#btn_open5").html(data);
				}
		});
	})
})
$(function() {
	$("#mus_h3_btn6").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile5/mus_h3_btn6.jsp', dataType: 'html', success: function(data) {
					$("#btn_open6").html(data);
				}
		});
	})
})
$(function() {
	$("#mus_h3_btn7").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile5/mus_h3_btn7.jsp', dataType: 'html', success: function(data) {
					$("#btn_open7").html(data);
				}
		});
	})
})
$(function() {
	$("#mus_h3_btn8").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile5/mus_h3_btn8.jsp', dataType: 'html', success: function(data) {
					$("#btn_open8").html(data);
				}
		});
	})
})