$(function() {
	$("#cul_h1_btn1").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn1.jsp', dataType: 'html', success: function(data) {
					$("#btn_open1").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn2").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn2.jsp', dataType: 'html', success: function(data) {
					$("#btn_open2").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn3").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn3.jsp', dataType: 'html', success: function(data) {
					$("#btn_open3").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn4").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn4.jsp', dataType: 'html', success: function(data) {
					$("#btn_open4").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn5").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn5.jsp', dataType: 'html', success: function(data) {
					$("#btn_open5").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn6").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn6.jsp', dataType: 'html', success: function(data) {
					$("#btn_open6").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn7").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn7.jsp', dataType: 'html', success: function(data) {
					$("#btn_open7").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn8").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn8.jsp', dataType: 'html', success: function(data) {
					$("#btn_open8").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn9").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn9.jsp', dataType: 'html', success: function(data) {
					$("#btn_open9").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn10").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn10.jsp', dataType: 'html', success: function(data) {
					$("#btn_open10").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn11").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn11.jsp', dataType: 'html', success: function(data) {
					$("#btn_open11").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn12").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn12.jsp', dataType: 'html', success: function(data) {
					$("#btn_open12").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn13").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn13.jsp', dataType: 'html', success: function(data) {
					$("#btn_open13").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn14").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn14.jsp', dataType: 'html', success: function(data) {
					$("#btn_open14").html(data);
				}
		});
	})
})
$(function() {
	$("#cul_h1_btn15").click(function() {
		$.ajax({
			type: 'post', url:
				'/htmlfile3/cul_h1_btn15.jsp', dataType: 'html', success: function(data) {
					$("#btn_open15").html(data);
				}
		});
	})
})